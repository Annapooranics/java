
package chapter01;

public interface Shapes 
{
    public void draw();
}
